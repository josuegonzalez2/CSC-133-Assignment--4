package com.mycompany.a4;

public interface ICollection {
	
	public void add(GameObject obj);
	
	public IIterator getIterator();
}
