package com.mycompany.commands;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a4.MapView;

public class ZoomCmd {
	private MapView mv;
	
	public ZoomCmd(MapView mv) {
		//super("Zoom");
		this.mv = mv;
	}
	
	public void actionPerformed(ActionEvent ev) {
		//if(mv.zoo)
	}

}
